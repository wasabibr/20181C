#include <stdio.h>

int main() {

	int a, n, x;

	//exemplo:
	//soma dos multiplos de 4 até 20:
	//4
	//+ (4 + 4)
	//+ (4 + 4 + 4)
	//+ (4 + 4 + 4 + 4)
	//+ (4 + 4 + 4 + 4 + 4) a quantidade de a's no último múltiplo pode ser obtido pela divisão inteira x = n/a
	//então esse somatório é dado por a*(a quantidade de a's)
	//a quantidade de a's é dada pelo somatório (1 + 2 + ... + x) = (x^2 + x)/2 (somatório por PA)
	//portanto a resposta é a*(x*x+x)/2
	scanf("%d %d", &a, &n);
	x = n/a;
	printf("%d\n", a*(x*x+x)/2);

	return 0;
}
