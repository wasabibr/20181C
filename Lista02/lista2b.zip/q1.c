#include <stdlib.h>
#include <stdio.h>

int main() {

	int a, b, c, qtd = 0, p;
	
	scanf("%d %d %d", &a, &b, &c);

	//calcula a quantidade de negativos
	if(a < 0) qtd++;
	if(b < 0) qtd++;
	if(c < 0) qtd++;

	//esses if/elses substituem numeros negativos caso possa afirmar qual é o brinquedo
	//caso contrário deixa o número negativo mesmo e os negativos serão impressos como ? no final do código
	if(qtd == 1) {
		//quando há somente 1 negativo, obter o brinquedo que falta através de 6 - somaDosOutrosDois
		//já que a soma de a + b + c sempre deve ser 6
		if(a < 0) a = 6-b-c;
		else if(b < 0) b = 6-a-c;
		else c = 6-b-a;
	} else if(qtd == 2 && !(abs(a) == abs(b) && abs(b) == abs(c))) {
		//quando há 2 negativos, desde que o módulo de todos não sejam iguais (ex -1 -1 1, -3 3 -3, etc)
		//pois nesses casos a resposta é ? para os negativos (verifique por que)
		
		//p vai ter o único número positivo
		p = a > 0 ? a : (b > 0 ? b : c);

		//se qualquer um dos negativos for -p, então substitua-o por -(6-abs(x)-abs(y))
		//exemplo: 1 -2 -1... o -1 será substituido por -3
		//usa abs para não ter que verificar qual dos outros dois é negativo
		if(a == -p)
			a = -(6-abs(b)-abs(c));
		if(b == -p)
			b = -(6-abs(a)-abs(c));
		if(c == -p)
			c = -(6-abs(a)-abs(b));

		//agora que há dois negativos e nenhum deles é -p, então dá para deduzir qual é cada um desses dois negativos (verifique)
		if(a < 0)
			a = 6+a-p;
		if(b < 0)
			b = 6+b-p;
		if(c < 0)
			c = 6+c-p;

	} else if(qtd == 3) {
		//se os 3 forem negativos e dois deles iguais, então esse é o brinquedo do que disse diferente
		//para os outros dois não é possível deduzir
		if(a == c)
			b = -a;
		else if(a == b)
			c = -a;
		else if(b == c)
			a = -b;
	}

	//escreve ? se for negativo ou '0' + valor caso contrário
	printf("%c ", a < 0 ? '?' : '0' + a);
	printf("%c ", b < 0 ? '?' : '0' + b);
	printf("%c\n", c < 0 ? '?' : '0' + c);

	return 0;
}
