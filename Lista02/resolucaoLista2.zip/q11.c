#include <stdio.h>

int main() {

	int renda, historicoBom;

	printf("Digite a renda mensal: ");
	scanf("%d", &renda);

	if(renda < 700) {
		printf("Resultado: alto risco\n");
	} else {
		printf("Digite se o histórico de crédito é bom: ");
		scanf("%d", &historicoBom);
		if(renda >= 700 && renda < 3200) {
			if(historicoBom) {
				printf("Resultado: médio risco\n");
			} else {
				printf("Resultado: alto risco\n");
			}
		} else { //caso renda >= 3200
			if(historicoBom)
				printf("Resultado: baixo risco\n");
			else 
				printf("Resultado: médio risco\n");
		}
	}

	return 0;
}
