
#include <stdio.h>

int main() {

	int a, b, c;

	scanf("%d %d %d", &a, &b, &c);

	if(a > b + c || b > a + c || c > a + b) {
		printf("Não existe\n");
	} else {
		printf("Existe\nClassificação: ");
		if(a == b && b == c) {
			printf("equilátero\n");
		} else {
			if(a == b || b == c || a == c) {
				printf("isósceles\n");
			} else {
				printf("escaleno\n");
			}
		}
	}


	return 0;
}

