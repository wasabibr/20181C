
#include <stdio.h>

int main() {

	float n1, n2, n3, m;
	char conceito;

	printf("Digite a primeira nota: ");
	scanf("%f", &n1);
	printf("Digite a segunda nota: ");
	scanf("%f", &n2);
	printf("Digite a terceira nota: ");
	scanf("%f", &n3);
	
	m = (n1 + n2 + n3)/3;

	if(m >= 9.5)
		conceito = 'A';
	else
		if(m >= 8.5)
			conceito = 'B';
		else
			if(m >= 7.0)
				conceito = 'C';
			else
				if(m >= 6.0)
					conceito = 'D';
				else
					conceito = 'F';

	printf("Conceito: %c\n", conceito);

	return 0;
}

