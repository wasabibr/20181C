#include <stdio.h>

int main() {

	int pts, ptsMinima, partidasRestantes;

	printf("Quantos pontos possui o time: ");
	scanf("%d", &pts);
	printf("Quantas partidas restam: ");
	scanf("%d", &partidasRestantes);
	printf("Quantos pontos são necessários: ");
	scanf("%d", &ptsMinima);

	if(pts >= ptsMinima) {
		printf("O time já está classificado\n");
	} else {
		if(ptsMinima - pts <= partidasRestantes*3) {
			printf("É possível se classificar\n");
		} else {
			printf("Não é possível se classificar\n");
		}
	}

	return 0;
}

