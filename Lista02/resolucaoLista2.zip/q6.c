#include <stdio.h>

int main() {

	int h1, m1, h2, m2;
	int total1, total2, dif;

	printf("Digite as horas do horário inicial: ");
	scanf("%d", &h1);
	printf("Digite os minutos do horário inicial: ");
	scanf("%d", &m1);
	printf("Digite as horas do horário final: ");
	scanf("%d", &h2);
	printf("Digite os minutos do horário final: ");
	scanf("%d", &m2);

	total1 = h1*60 + m1;
	total2 = h2*60 + m2;

	if(total1 > total2) {
		total2 += 24*60;
	}
	dif = total2 - total1;

	printf("Resultado: %dh%dmin\n", dif/60, dif%60); 
	return 0;
}

