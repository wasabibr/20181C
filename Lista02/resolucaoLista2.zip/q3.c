#include <stdio.h>

int main() {

	int a, b, c;

	//entrada de dados
	printf("Digite A: ");
	scanf("%d", &a);
	printf("Digite B: ");
	scanf("%d", &b);
	printf("Digite C: ");
	scanf("%d", &c);

	//se a for igual à soma de b e c OU b for igual à soma de a e c OU c for igual à soma de a e b
	if(a == b + c || b == a + c || c == a + b) {
		printf("Um dos números é a soma dos outros dois\n");
	} else { //senão
		printf("Nenhum dos números é a soma dos outros dois\n");
	}

	return 0;
}

