#include <stdio.h>
#include <stdlib.h>

int main() {

	int px, py; //posicao do primeiro cavalo
	int qx, qy; //posicao do segundo cavalo

	scanf("%d %d %d %d", &py, &px, &qy, &qx);

	//a função abs retorna o valor passado como argumento em módulo
	if( (abs(px - qx) == 1 && abs(py - qy) == 2) || (abs(px - qx) == 2 && abs(py - qy) == 1)) {
		printf("Resultado: atacam-se\n");
	} else {
		printf("Resultado: não se atacam\n");
	}

	return 0;
}

