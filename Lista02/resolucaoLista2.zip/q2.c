
#include <stdio.h>

int main() {

	int a, b;

	scanf("%d %d", &a, &b);

	//lembre-se bem do operador resto de divisão %
	if(a%b == 0)
		printf("Resultado: %d\n", a/b);


	return 0;
}

