
#include <stdio.h>

int main() {

	int a, b, c;

	scanf("%d %d", &a, &b);
	printf("antes da troca a = %d e b = %d\n", a, b);
	//é necessário primeiro copiar o valor de a para uma variável temporária c
	c = a;
	//agora atribuindo b à variável a
	a = b;
	//o valor antigo da variável a é recuperável na variável c
	b = c;
	printf("depois da troca a = %d e b = %d\n", a, b);

	return 0;
}

