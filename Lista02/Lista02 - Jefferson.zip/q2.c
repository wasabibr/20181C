#include <stdio.h>
 
main() {
 
	int a, b;
		
	scanf("%d %d", &a, &b);
	if(a%b==0){
		printf("Resultado: %d", a/b);
	}
				
	return 0; 

}
