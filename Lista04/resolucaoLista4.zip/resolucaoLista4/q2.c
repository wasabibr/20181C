
#include <stdio.h>

int main() {

	int n, i;
	float notas[30];
	float media = 0;
	int cont = 0;

	scanf("%d", &n);

	for(i = 0; i < n; i++) {
		scanf("%f", &notas[i]);
		media += notas[i];
	}
	media /= n;

	for(i = 0; i < n; i++) {
		if(notas[i] > media) {
			cont++;
		}
	}
	printf("%d\n", cont);

	

	return 0;
}

