
#include <stdio.h>

int main() {

	int n, i, x;
	int dias[20];
	int maior = 0;

	scanf("%d", &n);
	for(i = 0; i < n; i++) {
		scanf("%d", &dias[i]);
		if(dias[i] > maior) {
			maior = dias[i];
		}
	}

	for(i = 0; i < n; i++) {
		if(dias[i] == maior)
			printf("%d ", i+1);
	}

	printf("%d\n", maior);

	return 0;
}

