#include <string.h>
#include <stdio.h>

int main() {

	int presente[256];
	char string[100];

	for(int i = 0; i < 256; i++) {
		//marca o caractere i como nao presente (ao menos ainda), 0 indica falso
		presente[i] = 0;
	}

	fgets(string, 100, stdin);
	//ou gets(string);
	
	for(int i = 0; i < strlen(string); i++) {
		//marca o caractere string[i] como presente, 1 indica verdadeiro
		presente[string[i]] = 1;
	}

	for(int i = 0; i < 256; i++) {
		//se o caractere i não for uma letra minúscula passa para a próxima iteração
		if(!(i >= 'a' && i <= 'z'))
			continue;
		//se o caractere i não estiver presente, escreva-o na tela
		if(!presente[i])
			printf("%c ", i);
	}
	printf("\n");

	return 0;
}

