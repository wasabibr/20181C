#include <string.h>
#include <stdio.h>

int main() {

	char palavra[15];
	int i, cont = 0;
	char c;
	
	scanf("%s %c", palavra, &c);

	for(i = 0; i < strlen(palavra); i++) {
		if(palavra[i] == c) {
			cont++;
		}
	}
	printf("%d\n", cont);

	return 0;
}

