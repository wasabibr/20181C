
#include <stdio.h>

int main() {

	int n, i;
	int gabarito[20];
	int respostas[20];
	int acertos = 0;

	scanf("%d", &n);
	for(i = 0; i < n; i++) {
		scanf("%d", &gabarito[i]);
	}

	for(i = 0; i < n; i++) {
		scanf("%d", &respostas[i]);
	}

	for(i = 0; i < n; i++) {
		if(respostas[i] == gabarito[i]) {
			acertos++;
		}
	}
	printf("%d ", acertos);
	if(acertos == 1)
		printf("acerto\n");
	else
		printf("acertos\n");

	return 0;
}

