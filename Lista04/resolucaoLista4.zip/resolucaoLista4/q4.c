
#include <stdio.h>

int main() {

	int seq[10];
	int n, i, x;
	int marcado[10];
	int permutacao = 1;

	scanf("%d", &n);
	for(i = 1; i <= n; i++) {
		//inicialmente nenhum numero de 1 a n foi encontrado
		marcado[i] = 0;
	}
	for(i = 0; i < n; i++) {
		scanf("%d", &x);
		//se houver algum numero fora do intervalo, ja concluimos que nao eh permutacao
		if(x <= 0 || x > n) {
			permutacao = 0;
			continue;
		}
		//se o numero x ja estiver sido marcado, concluimos que nao eh permutacao
		if(marcado[x] == 1) 
			permutacao = 0;
		marcado[x] = 1;
	}
	if(permutacao) {
		printf("sim\n");
	} else {
		printf("não\n");
	}


	return 0;
}

