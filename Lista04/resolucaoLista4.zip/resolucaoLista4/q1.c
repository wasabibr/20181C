#include <stdio.h>
#include <string.h>

int main() {

	char campo[20];
	int x, qtd = 0;

	scanf("%s %d", campo, &x);
	if(campo[x] == '*') {
		printf("bum!\n");
	} else {
		//primeiro verifica se à direita é bomba (mas somente se não for o último)
		//incrementa qtd caso seja verdadeiro

		if(x+1 < strlen(campo) && campo[x+1] == '*') {
			qtd++;
		}
		
		//depois verifica se à esquerda é bomba (mas somente se não for o primeiro)
		//incrementa qtd caso seja verdadeiro
		if(x-1 >= 0 && campo[x-1] == '*') {
			qtd++;
		}
		
		//observe acima a ordem das verificações
		//caso fosse if(campo[x+1] == '*' && x+1 < strlen(campo)) e x+1 estivesse fora dos limites
		//estaremos acessando fora dos limites do vetor
		//mas como x+1 < strlen(campo) é verificado primeiro, caso seja verdadeiro
		// a segunda proposição (campo[x+1]) nem é verificada, pois falso E qualquer valor é necessariamente falso
		
		printf("%d\n", qtd);
	}

	return 0;
}

