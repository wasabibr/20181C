#include <string.h>
#include <stdio.h>

int main() {

	int cont[256];
	char string[200];

	for(int i = 0; i < 256; i++) {
		cont[i] = 0;
	}

	gets(string);
	for(int i = 0; i < strlen(string); i++)
		cont[string[i]]++;

	for(int i = 0; i < 256; i++) {
		if((i >= 'a' && i <= 'z') || (i >= 'A' && i <= 'Z')) {
			if(cont[i] > 0)
				printf("%c: %d\n", i, cont[i]);
		}
	}

	return 0;
}

