
#include <stdio.h>

int main() {

	char string[201];
	int cont[256], i;

	fgets(string, 200, stdin);

	for(i = 0; i < 256; i++)
		cont[i] = 0;

	for(i = 0; i < strlen(string); i++)
		cont[string[i]]++;

	for(i = 0; i < 256; i++)
		if((i >= 'a' && i <= 'z' || i >= 'A' && i <= 'Z') && cont[i] != 0)
			printf("%c: %d\n", i, cont[i]);

	printf("%s\n", string);

	return 0;
}

