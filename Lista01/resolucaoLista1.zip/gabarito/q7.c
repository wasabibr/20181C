#include <stdio.h>

int main() {
	
	printf("O poeta é um fingidor\n");
	printf("Finge tão completamente\n");
	printf("Que chega a fingir que é dor\n");
	printf("A dor que deveras sente.\n");

	return 0;
}

