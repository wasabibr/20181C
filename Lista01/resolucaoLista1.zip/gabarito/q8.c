#include <stdio.h>

int main() {

	char t;
	scanf("%c", &t);

	printf("%c\n", t+1);

	return 0;
}
