#include <stdio.h>

int main() {

	int a, b, c;

	scanf("%d", &a);
	scanf("%d", &b);
	scanf("%d", &c);

	printf("Resposta: %d\n", (a == b + c || b == a + c || c == a + b));

	return 0;
}

