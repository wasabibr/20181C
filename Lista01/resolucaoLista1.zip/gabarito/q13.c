#include <stdio.h>
#include <math.h>

int main() {

	int a, b, c;
	scanf("%d %d %d", &a, &b, &c);
	printf("%f\n", c - (3*a+2*b)/(c-(c*(a+b)*(a+b))/(sqrt(b))));

	return 0;
}

