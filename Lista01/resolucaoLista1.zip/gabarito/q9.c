#include <stdio.h>

int main() {

	float T, P;
	scanf("%f %f", &P, &T);
	printf("Nota: %.02f\n", P + P*T/9);

	return 0;
}


