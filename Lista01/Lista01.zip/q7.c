#include <stdio.h>

int main(){

	printf("O poeta é um fingidor\nFinge tão completamente\nQue chega a fingir que é dor\nA dor que deveras sente.\n");
	
	return 0;
}
