#include <stdio.h>

int main(){

	int a, b, r=0;

	scanf("%d %d", &a, &b);
	
	r=a%b;
	while(r!=0)
	{
		a=b;
		b=r;
		r=a%b;
	}
	printf("%d\n", b);
	
	return 0;
}

