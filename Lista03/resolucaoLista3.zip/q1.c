
#include <stdio.h>

int main() {

	int x, n;

	scanf("%d %d", &x, &n);
	for(int i = 0; i < n; i++) {
		//só escreva na tela a vírgula antes se não for a primeira iteração
		if(i != 0)
			printf(", ");
		//outra forma seria: escreva a vírgula depois somente se não for a última iteração
		
		printf("%d", x);
	}

	return 0;
}

