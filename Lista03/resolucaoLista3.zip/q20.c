#include <stdio.h>

int main() {

	float a, b, c;
	int dobras = 0;

	scanf("%f %f %f", &a, &b, &c);

	dobras = 0;
	while(a >= c && b >= c) {
		if(a > b) {
			a /= 2;
		} else {
			b /= 2;
		}
		dobras++;
	}
	printf("%d\n", dobras);

	return 0;
}

