
#include <stdio.h>

int main() {

	int a, b;
	int somaDivA, somaDivB;
	somaDivB = somaDivA = 0;

	scanf("%d %d", &a, &b);
	for(int i = 1; i < a; i++)
		if(a%i == 0)
			somaDivA += i;
	for(int i = 1; i < b; i++)
		if(b%i == 0)
			somaDivB += i;
	
	if(somaDivB == a && somaDivA == b)
		printf("sim");
	else
		printf("não");
	

	return 0;
}

