#include <stdio.h>

int main() {

	int a, b, i;

	scanf("%d %d", &a, &b);

	//se a < b
	if(a < b) {
		//o programa escreve de a até b, incrementando
		for(i = a; i <= b; i++) {
			printf("%d ", i);
		}
	} else { //senão
		//o programa escreve de b até a, decrementando
		for(i = a; i >= b; i--) {
			printf("%d ", i);
		}
	}
	printf("\n");

	return 0;
}
