
#include <stdio.h>

int main() {

	int n, b, ehExponenciacao, expoente;

	scanf("%d", &n);
	scanf("%d", &b);

	expoente = 0;
	ehExponenciacao = 1;
	while(n != 1) {
		expoente = expoente + 1; //expoente += 1; expoente++;
		if(n%b == 0) {
			n = n/b;
		} else {
			ehExponenciacao = 0;
			break; //encerra o laço de repetição imediato
		}
	}
	if(ehExponenciacao) {
		printf("sim\n");
	} else {
		printf("não\n");
	}


	return 0;
}
