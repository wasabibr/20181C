
#include <stdio.h>

int main() {

	//soma é uma variável cuja função é acumular o valor do somatório, inicialmente é zero
	int n, soma = 0;
	scanf("%d", &n);
	for(int i = 1; i <= n; i++)
		soma += i; //a cada iteração, o valor de soma é incrementado em i
	printf("%d\n", soma);

	return 0;
}

