
#include <stdio.h>

int main() {

	int a, b, c, n;

	a = b = 1;

	scanf("%d", &n);
	for(int i = 0; i < n-2; i++) {
		c = a + b;
		a = b;
		b = c;
	}
	printf("%d\n", b);

	return 0;
}

