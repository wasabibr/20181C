#include <stdio.h>

int main() {

	int i, n, num, maior;

	scanf("%d", &n);

	for(i = 1; i <= n; i++) {
		scanf("%d", &num);
		//veja que, uma vez que todos os números podem ser negativos, não podemos inicializar maior com 0
		//então uma solução seria atribuir num a maior caso num seja o maior de fato até aquele momento ou se for a primeira iteração
		if(i == 1 || num > maior) {
			maior = num;
		}
	}

	printf("%d\n", maior);

	return 0;
}
