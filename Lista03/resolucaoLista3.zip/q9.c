
#include <stdio.h>

int main() {

	int i, n, soma;
	scanf("%d", &n);

	soma = 0;
	for(i = 1; i < n; i++) {
		if(n%i == 0) { //verifica se i divide n. Se dividir, soma-se i em soma
			soma = soma + i; //mesma coisa que soma += i
		}
	}
	if(soma == n) {
		printf("Perfeito\n");
	} else {
		printf("Não perfeito\n");
	}

	return 0;
}
