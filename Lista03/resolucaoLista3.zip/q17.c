
#include <stdio.h>

int main() {

	int a, b, tmp, r;

	scanf("%d %d", &a, &b);
	if(b > a) {
		tmp = a;
		a = b;
		b = tmp;
	}

	while(a%b != 0) {
		r = a%b;
		a = b;
		b = r;
	}
	printf("%d\n", b);

	return 0;
}

