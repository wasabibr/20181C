
#include <stdio.h>

int main() {

	int n, x;
	int maior = 0;
	int atual = 0;

	scanf("%d", &n);

	for(int i = 0; i < n; i++) {
		scanf("%d", &x);
		if(x == 0) {
			atual++;
			if(atual > maior)
				maior = atual;
		} else {
			atual = 0;
		}
	}
	printf("%d\n", maior);

	return 0;
}

